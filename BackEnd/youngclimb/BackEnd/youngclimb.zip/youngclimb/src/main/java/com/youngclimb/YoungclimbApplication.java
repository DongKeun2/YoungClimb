package com.youngclimb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YoungclimbApplication {

	public static void main(String[] args) {
		SpringApplication.run(YoungclimbApplication.class, args);
	}

}
